const form = document.getElementById('qa-form');
const statusEl = document.getElementById('status');
const resultEl = document.getElementById('result');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  statusEl.textContent = 'Uploading & processing...';
  resultEl.textContent = '';

  const question = document.getElementById('question').value;
  const promptType = document.getElementById('promptType').value;
  const filesInput = document.getElementById('files');

  if (!question || question.trim().length === 0) {
    alert('Please enter a question');
    statusEl.textContent = 'Ready';
    return;
  }

  const fd = new FormData();
  fd.append('question', question);
  if (promptType) fd.append('promptType', promptType);

  for (let i = 0; i < filesInput.files.length; i++) {
    fd.append('files', filesInput.files[i], filesInput.files[i].name);
  }

  try {
    const resp = await fetch('/search/upload', {
      method: 'POST',
      body: fd
    });

    if (!resp.ok) {
      const text = await resp.text();
      resultEl.textContent = `Error: ${resp.status} - ${text}`;
      statusEl.textContent = 'Error';
      return;
    }

    const data = await resp.json();
    resultEl.textContent = data.output || JSON.stringify(data, null, 2);
    statusEl.textContent = 'Done';
  } catch (err) {
    resultEl.textContent = `Request failed: ${err.message || err}`;
    statusEl.textContent = 'Error';
  }
});
