import "dotenv/config";
import express from "express";
import path from "node:path";
import fs from "node:fs";
import { createChatModel, getModelInfo } from "./model.js";
import { buildQAChain } from "./chain.js";
import { loadDocumentToString } from "./loaders.js";
import { InvokeSchema, InvokeBody, InvokeResult } from "./types.js";

async function main() {
  // Dynamically import multer so this module remains ESM-friendly and doesn't use require()
  const multerModule = await import('multer');
  const multer = (multerModule as any).default ?? multerModule;

  const app = express();
  app.use(express.json({ limit: "10mb" }));
  // Serve a simple single-page app from `public/`
  app.use(express.static(path.join(process.cwd(), "public")));

  // Configure multer for file uploads (stored to ./uploads)
  const uploadDir = path.join(process.cwd(), "uploads");
  const storage = multer.diskStorage({
    destination: (req: any, file: any, cb: any) => {
      try {
        fs.mkdirSync(uploadDir, { recursive: true });
      } catch (e) {
        // ignore
      }
      cb(null, uploadDir);
    },
    filename: (req: any, file: any, cb: any) => {
      const name = `${Date.now()}_${file.originalname}`;
      cb(null, name);
    }
  });
  const upload = multer({ storage });

  // Health check endpoint
  app.get("/health", (req, res) => {
    const modelInfo = getModelInfo();
    res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      model: modelInfo
    });
  });

  // Upload multiple files and ask a question about them.
  // Expects multipart/form-data with fields:
  // - question (string)
  // - promptType (optional)
  // - files (one or more file inputs, name="files")
  app.post("/search/upload", upload.array("files"), async (req, res) => {
    const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    try {
      console.log(`\n[${requestId}] === NEW UPLOAD REQUEST RECEIVED ===`);

      const question = String(req.body?.question ?? "");
      const promptType = req.body?.promptType as string | undefined;

      if (!question) {
        throw new Error("Missing 'question' field in upload request");
      }

      const files = (req.files as any[]) || [];
      if (files.length === 0) {
        throw new Error("No files attached. Please attach one or more files using the 'files' field.");
      }

      console.log(`[${requestId}] Question: ${question}`);
      console.log(`[${requestId}] ${files.length} files uploaded`);

      const loadedParts: string[] = [];

      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        console.log(`[${requestId}] Loading uploaded file: ${f.path}`);
        const part = await loadDocumentToString(f.path);
        loadedParts.push(part);
      }

      const document = loadedParts.join("\n\n---DOCUMENT---\n\n");
      console.log(`[${requestId}] Combined document length: ${document.length} characters`);

      const modelInfo = getModelInfo();
      const model = createChatModel();
      const chain = buildQAChain(model, promptType as any);

      console.log(`[${requestId}] Processing with QA chain...`);
      const startTime = Date.now();

      const output = await chain.invoke({ document, question });

      const duration = Date.now() - startTime;
      console.log(`[${requestId}] Chain processing completed in ${duration}ms`);

      const result: InvokeResult = {
        output,
        model: modelInfo.model,
        provider: modelInfo.provider,
        promptType: promptType || "default"
      };

      res.json(result);
    } catch (err: any) {
      console.error(`\n[${requestId}] Upload request error:`, err.message ?? String(err));
      res.status(400).json({ error: err.message ?? String(err) });
    } finally {
      // Clean up uploaded files
      const files = (req.files as any[]) || [];
      for (const f of files) {
        try {
          fs.unlinkSync(f.path);
        } catch (e) {
          // ignore cleanup errors
        }
      }
    }
  });

  app.post("/search/document", async (req, res) => {
    const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    try {
      console.log(`\n[${requestId}] === NEW REQUEST RECEIVED ===`);
      console.log(`Timestamp: ${new Date().toISOString()}`);
      console.log(`Request Body:`, JSON.stringify(req.body, null, 2));

      const parsed = InvokeSchema.parse(req.body as InvokeBody);
      
      console.log(`[${requestId}] Request validated successfully`);
      console.log(`Question: "${parsed.question}"`);
      console.log(`Document source: ${parsed.documentPath ? `File: ${parsed.documentPath}` : `Inline text (${parsed.documentText?.length || 0} chars)`}`);
      console.log(`Prompt type: ${parsed.promptType || 'default'}`);

      const document =
        parsed.documentText ??
        (await loadDocumentToString(parsed.documentPath as string));

      console.log(`[${requestId}] Document loaded: ${document.length} characters`);

      const modelInfo = getModelInfo();
      console.log(`[${requestId}] Using model: ${modelInfo.provider}/${modelInfo.model}`);

      const model = createChatModel();
      const chain = buildQAChain(model, parsed.promptType);

      console.log(`[${requestId}] Processing with QA chain...`);
      const startTime = Date.now();

      const output = await chain.invoke({
        document,
        question: parsed.question
      });

      const duration = Date.now() - startTime;
      console.log(`[${requestId}] Chain processing completed in ${duration}ms`);
      console.log(`[${requestId}] Output length: ${output.length} characters`);

      const result: InvokeResult = {
        output,
        model: modelInfo.model,
        provider: modelInfo.provider,
        promptType: parsed.promptType || "default"
      };

      console.log(`📤 [${requestId}] Sending response to client`);
      console.log(`====================================\n`);

      res.json(result);
    } catch (err: any) {
      console.error(`\n[${requestId}] === REQUEST ERROR ===`);
      console.error(`Error:`, err.message ?? String(err));
      console.error(`Stack:`, err.stack);
      console.error(`====================================\n`);

      res.status(400).json({ error: err.message ?? String(err) });
    }
  });

  const port = Number(process.env.PORT ?? 8787);
  const host = process.env.HOST ?? "localhost";
  const serverUrl = process.env.SERVER_URL ?? `http://${host}:${port}`;

  app.listen(port, () => {
    const modelInfo = getModelInfo();
    console.log(`QA Bot API listening on ${serverUrl}`);
    console.log(`Provider: ${modelInfo.provider}`);
    console.log(`Model: ${modelInfo.model}`);
    console.log(`Temperature: ${modelInfo.temperature}`);
  });
}

main().catch((err) => {
  console.error("Server start failed:", err);
  process.exit(1);
});
